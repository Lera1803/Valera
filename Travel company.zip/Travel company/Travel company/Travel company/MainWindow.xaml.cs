﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Travel_company
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int comp;
        Туристическая_фирмаEntities db = Helper.GetContext();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Clients.ItemsSource = db.Tourists.ToList();
            ClientsInfo.ItemsSource = db.ClientInfo.ToList();
        }

        private void Clients_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            update.Visibility = Visibility.Visible;
            Clients.ItemsSource = db.Tourists.ToList();
            comp = Clients.SelectedIndex;
            ClientsInfo.ItemsSource = db.ClientInfo.Where(a => a.ID_tourist == comp + 1).ToList();
            Helper.RemID = comp + 1;
        }

        private void ClientsInfo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            update.Visibility = Visibility.Visible;
            ClientsInfo.ItemsSource = db.ClientInfo.ToList();
            comp = ClientsInfo.SelectedIndex;
            Clients.ItemsSource = db.Tourists.Where(a => a.ID_tourist == comp + 1).ToList();
            Helper.RemID = comp + 1;
        }

        private void update_Click(object sender, RoutedEventArgs e)
        {
            update.Visibility = Visibility.Hidden;
            ClientsInfo.ItemsSource = db.ClientInfo.ToList();
            Clients.ItemsSource = db.Tourists.ToList();
            textbox1.Text = "";
            textbox2.Text = "";
            textbox3.Text = "";
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            Туристическая_фирмаEntities ConnectObject = new Туристическая_фирмаEntities();
            Tourists tourist = ConnectObject.Tourists.Where(o => o.ID_tourist == Helper.RemID).FirstOrDefault();
            ClientInfo infoAboutTourists = ConnectObject.ClientInfo.Where(o => o.ID_tourist == Helper.RemID).FirstOrDefault();
            ConnectObject.Tourists.Remove(tourist);
            ConnectObject.ClientInfo.Remove(infoAboutTourists);
            ConnectObject.SaveChanges();
            Clients.ItemsSource = db.Tourists.ToList();
            ClientsInfo.ItemsSource = db.ClientInfo.ToList();
            update.Visibility = Visibility.Hidden;
        }

        private void edit_Click(object sender, RoutedEventArgs e)
        {
            edit editTourist = new edit();
            editTourist.ShowDialog();
            Clients.ItemsSource = db.Tourists.ToList();
            ClientsInfo.ItemsSource = db.ClientInfo.ToList();
            update.Visibility = Visibility.Hidden;
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            Add addTourist = new Add();
            addTourist.ShowDialog();
            Clients.ItemsSource = db.Tourists.ToList();
            ClientsInfo.ItemsSource = db.ClientInfo.ToList();
        }
    }
}
