﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Travel_company
{
    /// <summary>
    /// Логика взаимодействия для Add.xaml
    /// </summary>
    public partial class Add : Window
    {
       Туристическая_фирмаEntities db = Helper.GetContext();
        public Add()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, RoutedEventArgs e)
        {
            int MaxId = db.Tourists.Max(x => x.ID_tourist) + 1;
            Туристическая_фирмаEntities ConnectObject = new Туристическая_фирмаEntities();
            Tourists tourist = new Tourists()
            {
                ID_tourist = MaxId,
                name = 
                surname = 
                patronymic = 
            };
            ClientInfo touristinfo = new ClientInfo()
            {
                ID_tourist = MaxId,
                passport_series =
                city =
                country = 
                phone = 
                index = 
            };
            ConnectObject.Tourists.Add(tourist);
            ConnectObject.ClientInfo.Add(touristinfo);
            ConnectObject.SaveChanges();
            this.Close();
        }
    }
}
