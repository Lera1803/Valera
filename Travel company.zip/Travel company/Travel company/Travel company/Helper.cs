﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Travel_company
{
    class Helper
    {
        public static int RemID;
        private static Туристическая_фирмаEntities ConnnectObject;
        public static Туристическая_фирмаEntities GetContext()
        {
            if (ConnnectObject == null)
            {
                ConnnectObject = new Туристическая_фирмаEntities();
            }
            return ConnnectObject;
        }

    }
}
